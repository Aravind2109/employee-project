package com.employee.info.domain;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(NullPointerException.class)
	public ResponseEntity<Object> handleException(NullPointerException ne)
	{
		return new ResponseEntity<Object>("Missing required param",HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<Object> handleException(IllegalArgumentException ne)
	{
		return new ResponseEntity<Object>("job level id must be between 1 to 10",HttpStatus.BAD_REQUEST);
	}
	
}
