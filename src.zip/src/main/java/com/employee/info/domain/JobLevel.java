package com.employee.info.domain;

public class JobLevel {

	private int jobLevelId;
	private String jobLevelname;
	private int basicPay;
	
	
	public int getJobLevelId() {
		return jobLevelId;
	}
	public void setJobLevelId(int jobLevelId) {
		this.jobLevelId = jobLevelId;
	}
	public String getJobLevelname() {
		return jobLevelname;
	}
	public void setJobLevelname(String jobLevelname) {
		this.jobLevelname = jobLevelname;
	}
	public int getBasicPay() {
		return basicPay;
	}
	public void setBasicPay(int basicPay) {
		this.basicPay = basicPay;
	}
	
	
}
