package com.employee.info.domain;

public class employee {
	
	private Integer employeeid;
	private Integer joblevelId;
	
	private String firstname;
	private String lastname;
	private Integer departmentid;
	private String emailid;
	private Integer managerid;
	
	public Integer getJoblevelId() {
		return joblevelId;
	}
	public void setJoblevelId(Integer joblevelId) {
		this.joblevelId = joblevelId;
	}
	public int getEmployeeid() {
		return employeeid;
	}
	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public int getDepartmentid() {
		return departmentid;
	}
	public void setDepartmentid(int departmentid) {
		this.departmentid = departmentid;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public int getManagerid() {
		return managerid;
	}
	public void setManagerid(int managerid) {
		this.managerid = managerid;
	}
	
	
	

}
