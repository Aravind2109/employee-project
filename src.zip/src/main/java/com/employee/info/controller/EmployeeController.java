package com.employee.info.controller;

import org.springframework.web.bind.annotation.RestController;

import com.employee.info.domain.employee;

import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
public class EmployeeController {

	@RequestMapping(value="/employee",method=RequestMethod.GET) 
	public employee getEmployee() { employee Emp = new employee();
	  Emp.setEmployeeid(01);
	Emp.setEmailid("john@gmail.com"); 
	  Emp.setFirstname("John");
	  Emp.setLastname("Jack"); 
	  Emp.setDepartmentid(23);
	  Emp.setManagerid(12);
	  Emp.setJoblevelId(3);
	  return Emp;
	  }
	 
	
	@RequestMapping(value="/employee",method=RequestMethod.PUT) 
	public employee updateEmp( @RequestBody employee Empdetails) throws Exception
	{
		if(Empdetails.getJoblevelId()>10)
		{
			throw new IllegalArgumentException();
		}
		  if(Empdetails == null) { throw new NullPointerException(); }
		  
		  if(Empdetails.getEmailid().isEmpty()) { throw new NullPointerException(); }
		  if(Empdetails.getFirstname().isEmpty()) { throw new NullPointerException(); }
		  if(Empdetails.getLastname().isEmpty()) { throw new NullPointerException(); }
		 
		
		employee Emp = new employee();
		Emp.setEmployeeid(Empdetails.getEmployeeid());
		Emp.setDepartmentid(Empdetails.getDepartmentid());
		Emp.setManagerid(Empdetails.getDepartmentid());
		Emp.setEmailid(Empdetails.getEmailid());
		Emp.setFirstname(Empdetails.getFirstname());
		Emp.setLastname(Empdetails.getLastname());
		return Emp;
		
	}
}
